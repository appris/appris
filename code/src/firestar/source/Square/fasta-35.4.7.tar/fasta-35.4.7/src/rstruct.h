
/* $Id: rstruct.h 28 2008-06-30 16:31:45Z pearson $ */
/* $Revision$  */

#ifndef RSTRUCT
#define RSTRUCT
struct rstruct
{
  int score[3];
  double comp;
  double H;
  double escore;
  int segnum;
  int seglen;
};
#endif
