#include "kalign2.h"


void stats(struct alignment* aln)
{
	int i,j;
	float 
	
	for (i = 0; i < numseq-1;i++){
		for (j = i + 1; j < numseq;j++){
			for (j = 0; j < aln->sl[f];j++){
		}
		f = aln->nsip[i];
		fprintf(stdout,">%s\n",aln->sn[f]);
		c = 0;
		for (j = 0; j < aln->sl[f];j++){
			tmp = aln->s[f][j];]
			aln->seq[f][j]
		}
	}
}


